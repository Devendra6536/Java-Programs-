package com.objectCloning;

import java.util.Scanner;

public class Example {

	public static void main(String[] args) {
		 Scanner scanner = new Scanner(System.in);
	        double payment = scanner.nextDouble();
	        float p = ((float)payment%1000);
	        System.out.println(p);
//	        String s = to_string(payment/100);
	        
	  
	}
}
