package max;

public interface SPLCheck {
	String checkSPL(String str);
}
