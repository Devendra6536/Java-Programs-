package com.bank;

public class Account {

}
